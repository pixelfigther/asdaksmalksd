//
// Created by Ali Şen on 26.10.2024.
//
#include <iostream>
using namespace std;
#include "mission.h"

mission::mission(const string name, const string launchDate, const string destination) {
    this->name = name;
    this->launchDate = launchDate;
    this->destination = destination;
    this->assSpaceCraftCount = 0;
    this->missionSpaceCrafts = nullptr;

}
mission::mission() {
    this->name = "";
    this->launchDate = "";
    this->destination = "";
    this->assSpaceCraftCount = 0;
    this->missionSpaceCrafts = nullptr;
}
mission::~mission(){
    delete[] missionSpaceCrafts;

}

string mission::getName() const{
    return name;
}
string mission::getLaunchDate() const{
    return launchDate;
}
string mission::getDestination() const {
    return destination;
}
int mission::getAssSpaceCraftCount() const {
    return assSpaceCraftCount;
}
void mission::assignSpaceCraft() {
    assSpaceCraftCount++;
}
void mission::dropSpaceCraft() {
    if(assSpaceCraftCount>0){
    assSpaceCraftCount--;
    }
}

void mission::assignSpaceCraftArray(const spaceCraft &spacecraft)  {
    // Check if the spacecraft is already in the array
    for (int i = 0; i < assSpaceCraftCount; i++) {
        if (missionSpaceCrafts[i].getName() == spacecraft.getName()) {
            return; // Spacecraft already assigned, do nothing
        }
    }

    // Create a new array with one more spacecraft
    spaceCraft* newMissionSpaceCrafts = new spaceCraft[assSpaceCraftCount + 1];

    // Copy existing spacecrafts to the new array
    for (int i = 0; i < assSpaceCraftCount; i++) {
        newMissionSpaceCrafts[i] = missionSpaceCrafts[i]; // Use copy assignment
    }

    // Add the new spacecraft to the end of the new array
    newMissionSpaceCrafts[assSpaceCraftCount] = spacecraft;

    // Free the old memory
    delete[] missionSpaceCrafts;
    missionSpaceCrafts = newMissionSpaceCrafts; // Update pointer to the new array
    assSpaceCraftCount++; // Increment spacecraft count
}

void mission::dropSpaceCraftArray(const spaceCraft &spacecraft)  {
    if (assSpaceCraftCount <= 0) return; // Nothing to drop

    int indexToRemove = -1;

    // Find the index of the spacecraft to remove
    for (int i = 0; i < assSpaceCraftCount; i++) {
        if (missionSpaceCrafts[i].getName() == spacecraft.getName()) {
            indexToRemove = i;
            break;
        }
    }

    // If the spacecraft is not found, do nothing
    if (indexToRemove == -1) return;

    // Create a new array with one less spacecraft
    spaceCraft* newMissionSpaceCrafts = new spaceCraft[assSpaceCraftCount - 1];

    // Copy all elements except the one to remove
    for (int i = 0, j = 0; i < assSpaceCraftCount; i++) {
        if (i != indexToRemove) {
            newMissionSpaceCrafts[j++] = missionSpaceCrafts[i];
        }
    }

    delete[] missionSpaceCrafts; // Free the old memory
    missionSpaceCrafts = newMissionSpaceCrafts; // Update pointer to the new array
    assSpaceCraftCount--; // Decrement spacecraft count
}

void mission::printAssSpaceCrafts() {
    for (int i = 0; i < assSpaceCraftCount; i++) {
        cout << "  - " << missionSpaceCrafts[i].getName() << endl;
    }
}




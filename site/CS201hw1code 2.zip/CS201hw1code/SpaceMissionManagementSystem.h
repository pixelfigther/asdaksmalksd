//
// Created by Ali Şen on 26.10.2024.
//
#include <iostream>
using namespace std;
#include "mission.h"


class SpaceMissionManagementSystem {
public:
    SpaceMissionManagementSystem();
    ~SpaceMissionManagementSystem();
    void addMission( const string name, const string launchDate, const string
    destination );
    void removeMission( const string name );
    void addSpacecraft( const string name, const string type );
    void removeSpacecraft( const string name );
    void assignSpacecraftToMission( const string spacecraftName, const string
    missionName );
    void dropSpacecraftFromMission( const string spacecraftName );
    void showAllMissions() const;
    void showAllSpacecrafts() const;
    void showMission( const string name ) const;
    void showSpacecraft( const string name ) const;
    void printAllSpaceCrafts();

private:
    int spaceCraftCount, missionCount;
    spaceCraft* allSpaceCrafts;
    mission* allMissions;
};
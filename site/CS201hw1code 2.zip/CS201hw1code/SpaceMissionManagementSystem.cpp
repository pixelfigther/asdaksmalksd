//
// Created by Ali Şen on 26.10.2024.
//
#include <iostream>
#include "SpaceMissionManagementSystem.h"
using namespace std;

SpaceMissionManagementSystem::SpaceMissionManagementSystem() {
    this->spaceCraftCount = 0;
    this->missionCount = 0;
    this->allSpaceCrafts = nullptr;
    this->allMissions = nullptr;
}
SpaceMissionManagementSystem::~SpaceMissionManagementSystem(){
delete[] allSpaceCrafts;
delete[] allMissions;
}

void SpaceMissionManagementSystem::addMission(const string name, const string launchDate,const string destination) {
mission newMission(name, launchDate, destination);
if(missionCount == 0){
    allMissions = new mission[1];
    allMissions[0] = newMission;
    missionCount++;
    cout<< "Added mission " << name <<"." << endl;
}
else{
int nameCheck = 0;
for(int i=0; i<missionCount; i++) {
    if (allMissions[i].getName() == name) {
        nameCheck = 1;
    }
}
       if(nameCheck == 1){
           cout<< "Cannot add mission. Mission " << name << " already exists."<< endl;
       }else{
         mission* newAllMissions = new mission[missionCount+1];
         for(int j=0;j<missionCount; j++){
             newAllMissions[j] = allMissions[j];
         }
         missionCount++;
         newAllMissions[missionCount-1] = newMission;
         delete[] allMissions;
         allMissions = newAllMissions;
         cout<< "Added mission " << name <<"." << endl;
       }
   }
 }
 void SpaceMissionManagementSystem::removeMission(const string name) {
    int index = 0;
    bool isThereMission = false;
    for(int i=0; i<missionCount; i++) {
        if (allMissions[i].getName() == name) {
            index = i;
            isThereMission = true;
        }
    }
        if(!isThereMission){
            cout << "Cannot remove mission. Mission " << name << " does not exist."<< endl;
        }else{
            for(int i=0;i<spaceCraftCount;i++){
                if(allSpaceCrafts[i].getMissionName()== allMissions[index].getName()){
                    allSpaceCrafts[i].setMissionName("");
                    allSpaceCrafts[i].setIsOnMission(false);
                    allSpaceCrafts[i].setStatusName("Available");
                }
            }
            mission* newAllMissions = new mission[missionCount-1];
            for(int i=0; i<index;i++){
                newAllMissions[i] = allMissions[i];
            }
            for(int i=index+1; i<missionCount;i++){
                newAllMissions[i-1] = allMissions[i];
            }
            missionCount--;
            delete[] allMissions;
            allMissions = newAllMissions;
            cout << "Removed mission " << name << "." <<endl;
    }
  }
void SpaceMissionManagementSystem::addSpacecraft(const string name, const string type) {
    spaceCraft newSpaceCraft(name,type);
    if(spaceCraftCount==0){
        allSpaceCrafts = new spaceCraft[1];
        allSpaceCrafts[0] = newSpaceCraft;
        spaceCraftCount++;
        cout<< "Added spacecraft "<< name <<"."<< endl;
    }
    else{
        int namecheck = 0;
        for(int i=0; i<spaceCraftCount;i++){
            if(allSpaceCrafts[i].getName()==name){
                namecheck = 1;
            }
        }
        if(namecheck == 1){
            cout<< "Cannot add spacecraft. Spacecraft "<< name << " already exists."<< endl;

        }else{
            spaceCraft* newSpaceCrafts = new spaceCraft[spaceCraftCount+1];
            for(int i=0;i<spaceCraftCount;i++){
                newSpaceCrafts[i] = allSpaceCrafts[i];
            }
            spaceCraftCount++;
            newSpaceCrafts[spaceCraftCount-1] = newSpaceCraft;
            delete[] allSpaceCrafts;
            allSpaceCrafts = newSpaceCrafts;

            cout<< "Added spacecraft "<< name <<"."<< endl;
        }
    }
}
void SpaceMissionManagementSystem::removeSpacecraft(const string name) {
    int index = 0;
    bool isThereSpaceCraft = false;
    for(int i=0; i<spaceCraftCount; i++) {
        if (allSpaceCrafts[i].getName() == name) {
            index = i;
            isThereSpaceCraft = true;
        }
    }
    if(!isThereSpaceCraft){
        cout << "Cannot remove spacecraft. Spacecraft " << name << " does not exist."<< endl;
    }else if(allSpaceCrafts[index].isOnMission()){
        cout <<"Cannot remove spacecraft. Spacecraft " << name << " is assigned to a mission."<<endl;
    }else{

        spaceCraft* newAllSpaceCrafts = new spaceCraft[spaceCraftCount-1];
        for(int i=0; i<index;i++){
            newAllSpaceCrafts[i] = allSpaceCrafts[i];
        }
        for(int i=index+1; i<spaceCraftCount;i++){
            newAllSpaceCrafts[i-1] = allSpaceCrafts[i];
        }
        spaceCraftCount--;
        delete[] allSpaceCrafts;
        allSpaceCrafts = newAllSpaceCrafts;
        cout << "Removed spacecraft " << name << "." <<endl;
        /*for(int i=0;i<spaceCraftCount;i++){
            cout << allSpaceCrafts[i].getName()<< endl;
        }*/

    }
}
void SpaceMissionManagementSystem::assignSpacecraftToMission(const string spacecraftName,const string missionName) {
int index = 0;
bool doesExist = false;
    for(int i=0;i<spaceCraftCount;i++){
    if(allSpaceCrafts[i].getName() == spacecraftName){
        index = i;
        doesExist= true;
        //cout << allSpaceCrafts[i].getName() << endl;
     }
    }
    bool doesExistMission = false;
    int indexM = 0;
        for(int i=0;i<missionCount;i++){
            if(allMissions[i].getName() == missionName){
                doesExistMission= true;
                indexM = i;
            }
        }

    if(!doesExist){
        cout << "Cannot assign spacecraft. Spacecraft "<< spacecraftName <<" does not exist." << endl;
    }
    else if(!doesExistMission) {
        cout<< "Cannot assign spacecraft. Mission "<< missionName << " does not exist."<< endl;
    }
    else if(allSpaceCrafts[index].isOnMission()){
        cout <<"Cannot assign spacecraft. Spacecraft "<< spacecraftName<<" is already assigned to mission "<< allSpaceCrafts[index].getMissionName()<< "."<<endl;
    }
    else {
        allMissions[indexM].assignSpaceCraftArray(allSpaceCrafts[index]);
        allSpaceCrafts[index].setIsOnMission(true);
        allSpaceCrafts[index].setMissionName(missionName);
        allSpaceCrafts[index].setStatusName("Assigned");

        cout <<"Assigned spacecraft "<< spacecraftName<< " to mission " << missionName<<"."<< endl;

    }

}
void SpaceMissionManagementSystem::dropSpacecraftFromMission(const string spacecraftName) {
    int index =0;
    bool doesExist = false;
    for(int i=0;i<spaceCraftCount;i++){
        if(allSpaceCrafts[i].getName()== spacecraftName){
            index = i;
            doesExist = true;
        }
    }
   // bool doesExistMission = false;
    int indexM = 0;
    for(int i=0;i<missionCount;i++){
        if(allMissions[i].getName() == allSpaceCrafts[index].getMissionName()){
            //doesExistMission= true;
            indexM = i;
        }
    }
    if(!doesExist){
        cout << "Cannot drop spacecraft. Spacecraft " << spacecraftName << " does not exist." << endl;
    }
   else if(!allSpaceCrafts[index].isOnMission()){
        cout<< "Cannot drop spacecraft. Spacecraft "<< spacecraftName << " is not assigned to any mission."  << endl;
    }else{
        allMissions[indexM].dropSpaceCraftArray(allSpaceCrafts[index]);
        allSpaceCrafts[index].setIsOnMission(false);
        allSpaceCrafts[index].setStatusName("Available");
        cout << "Dropped spacecraft "<< spacecraftName << " from mission " << allSpaceCrafts[index].getMissionName() <<"."<<endl;
        allSpaceCrafts[index].setMissionName("");
    }
}
void SpaceMissionManagementSystem::showAllMissions() const {
    if(missionCount== 0){
        cout << "Missions in the space mission management system:" << endl;
        cout << "None" << endl;
    }else{
        cout << "Missions in the space mission management system:"<< endl;
    for(int i=0; i<missionCount; i++){
        cout << "Mission: " << allMissions[i].getName() << ", Launch Date: " << allMissions [i].getLaunchDate() << ", Destination: " << allMissions[i].getDestination() << ", Assigned Spacecraft Count: "<< allMissions[i].getAssSpaceCraftCount() << endl;
        }
    }
}
void SpaceMissionManagementSystem::showAllSpacecrafts() const {
    if(spaceCraftCount==0){
        cout << "Spacecrafts in the space mission management system:" << endl;
        cout << "None" << endl;
    }else{
        cout << "Spacecrafts in the space mission management system:" << endl;
        for(int i=0; i<spaceCraftCount;i++){
            cout << "Spacecraft: " <<allSpaceCrafts[i].getName() << ", Type: " << allSpaceCrafts[i].getType() << ", Status: " << allSpaceCrafts[i].getStatusName()<< endl;
        }
    }
}
void SpaceMissionManagementSystem::showMission(const string name) const {
    int indexM = 0;
    bool doesExistM = false;
    for (int i=0; i<missionCount; i++){
        if(allMissions[i].getName() == name){
            indexM = i;
            doesExistM = true;
        }
    }
    if(!doesExistM){
        cout<< "Cannot show mission. Mission " << name << " does not exist." << endl;
    }else{
        cout<< "Mission:"<< endl;
        cout << "  Name: " << allMissions[indexM].getName() << endl;
        cout << "  Launch Date: " << allMissions[indexM].getLaunchDate()<< endl;
        cout << "  Destination: " << allMissions[indexM].getDestination() << endl;
        cout << "  Assigned Spacecrafts:" << endl;
        if(allMissions[indexM].getAssSpaceCraftCount()==0){cout <<"    None"<< endl;}
        else {

            allMissions[indexM].printAssSpaceCrafts();}
       }
}
void SpaceMissionManagementSystem::showSpacecraft(const string name) const {
    bool doesExist = false;
    int index = 0;
    for(int i=0; i<spaceCraftCount;i++){
        if(allSpaceCrafts[i].getName() == name){
            index = i;
            doesExist = true;
        }
    }
    if(!doesExist){cout << "Cannot show spacecraft. Spacecraft "<< name << " does not exist."<<endl;}
    else{cout << "Spacecraft: "<< allSpaceCrafts[index].getName() << ", Type: " <<allSpaceCrafts[index].getType() <<", Status: "<< allSpaceCrafts[index].getStatusName()<< endl; }
}

void SpaceMissionManagementSystem::printAllSpaceCrafts() {
    for(int i=0; i<spaceCraftCount; i++){
        cout << allSpaceCrafts[i].getName() << endl;
    }
}




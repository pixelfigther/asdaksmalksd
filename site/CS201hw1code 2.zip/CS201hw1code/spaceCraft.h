//
// Created by Ali Şen on 26.10.2024.
//

#include <string>
using namespace std;

class spaceCraft {
public:
    spaceCraft(const string name, const string type);
    spaceCraft();
    ~spaceCraft();

    string getName() const;
    string getType() const;
    bool isOnMission();
    void setIsOnMission(bool onMission);
    string getMissionName();
    void setMissionName(string missionName);
    string getStatusName();
    void setStatusName(string status);


private:
    string name, type, missionName, status;
    bool onMission;
};




//
// Created by Ali Şen on 26.10.2024.
//
#include <string>
#include "spaceCraft.h"
using namespace std;

spaceCraft::spaceCraft(const string name, const string type) {
    this->name = name;
    this->type = type;
    this->onMission = false;
    this->status = "Available";

}
spaceCraft::spaceCraft() {
  this->name = "";
  this->type = "";
  this->onMission = false;
    this->status = "Available";
}
spaceCraft::~spaceCraft(){}

string spaceCraft::getName() const {
    return name;
}
string spaceCraft::getType() const {
    return type;
}
bool spaceCraft::isOnMission() {
    return onMission;
}
void spaceCraft::setIsOnMission(bool onMission) {
    this->onMission = onMission;
}
string spaceCraft::getMissionName() {
    return missionName;
}
void spaceCraft::setMissionName(string missionName) {
    this->missionName = missionName;
}
string spaceCraft::getStatusName() {
    return status;
}
void spaceCraft::setStatusName(string status) {
    this->status = status;
}
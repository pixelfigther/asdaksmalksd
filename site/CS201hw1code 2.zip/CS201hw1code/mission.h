//
// Created by Ali Şen on 26.10.2024.
//

#include <string>
using namespace std;
#include "spaceCraft.h"

class mission{
public:
    mission(const string name, const string launchDate, const string destination );
    mission();
    ~mission();
    int getAssSpaceCraftCount() const;
    string getName() const;
    string getLaunchDate() const;
    string getDestination() const;
    void assignSpaceCraft();
    void dropSpaceCraft();
    void assignSpaceCraftArray(const spaceCraft& spacecraft);
    void dropSpaceCraftArray(const spaceCraft& spacecraft);
    void printAssSpaceCrafts();


private:
string name, launchDate, destination;
int assSpaceCraftCount;
spaceCraft* missionSpaceCrafts;
};
#include <string>
#ifndef MISSION_H
#define MISSION_H

using namespace std;

class Mission {
public:
    string name;
    string launchDate;
    string destination;
    string* assignedSpacecrafts; // Dynamically allocated array of spacecraft names
    int assignedCount;
    int assignedCapacity;

    Mission(const string& name, const string& launchDate, const string& destination);
    ~Mission();
    void addSpacecraft(const string& spacecraftName);
    void removeSpacecraft(const string& spacecraftName);
    void show() const;
};

#endif 
#include <iostream>
#include "SpaceMissionManagementSystem.h"

SpaceMissionManagementSystem::SpaceMissionManagementSystem()
    : missionCount(0), spacecraftCount(0), missions(nullptr), spacecrafts(nullptr) {}

SpaceMissionManagementSystem::~SpaceMissionManagementSystem() {
    delete[] missions;
    delete[] spacecrafts;
}

void SpaceMissionManagementSystem::addMission(const string name, const string launchDate, const string destination) {
    if (findMissionIndex(name) != -1) {
        cout << "Mission already exists." << endl;
        return;
    }
    
    Mission* newMissions = new Mission[missionCount + 1];
    for (int i = 0; i < missionCount; ++i) {
        newMissions[i] = missions[i]; 
    }

    newMissions[missionCount] = Mission(name, launchDate, destination);
    delete[] missions; 
    missions = newMissions; 
    missionCount++; 
}

void SpaceMissionManagementSystem::removeMission(const string name) {
    if (findMissionIndex(name) == -1) {
        cout << "Mission does not exist." << endl;
        return;
    }

    for (int i = 0; i < spacecraftCount; ++i) {
        if (spacecrafts[i].getAssignedMission() == name) {
            spacecrafts[i].unassign();
        }
    }

    for (int i = index; i < missionCount - 1; ++i) {
        missions[i] = missions[i + 1];
    }
    missionCount--;
}

void SpaceMissionManagementSystem::addSpacecraft(const string name, const string type) {
    if (findSpacecraftIndex(name) != -1) {
        cout << "Spacecraft already exists." << endl;
        return;
    }
    Spacecraft* newSpacecrafts = new Spacecraft[spacecraftCount + 1];
    Spacecraft* newSpacecrafts = new Spacecraft[spacecraftCount + 1];

    for (int i = 0; i < spacecraftCount; ++i) {
        newSpacecrafts[i] = spacecrafts[i];
    }

    delete[] spacecrafts;
    spacecrafts = newSpacecrafts;
    spacecrafts[spacecraftCount++] = Spacecraft(name, type);
}

void SpaceMissionManagementSystem::removeSpacecraft(const string name) {
    int index = findSpacecraftIndex(name);
    if (index == -1) {
        cout << "Spacecraft does not exist." << endl;
        return;
    }
    if (spacecrafts[index].getStatus() == "Assigned") {
        cout << "Cannot remove spacecraft: It is currently assigned to a mission." << endl;
        return;
    }
    for (int i = index; i < spacecraftCount - 1; ++i) {
        spacecrafts[i] = spacecrafts[i + 1];
    }
    --spacecraftCount;
}

void SpaceMissionManagementSystem::assignSpacecraftToMission(const string spacecraftName, const string missionName) {
    int spacecraftIndex = findSpacecraftIndex(spacecraftName);
    int missionIndex = findMissionIndex(missionName);

    if (spacecraftIndex == -1) {
        cout << "Spacecraft does not exist." << endl;
        return;
    }
    if (missionIndex == -1) {
        cout << "Mission does not exist." << endl;
        return;
    }
    if (spacecrafts[spacecraftIndex].getStatus() == "Assigned") {
        cout << "Spacecraft is already assigned to a mission." << endl;
        return;
    }

    spacecrafts[spacecraftIndex].assignToMission(missionName);
    missions[missionIndex].addSpacecraft(spacecraftName);
}

// Drop a spacecraft from a mission
void SpaceMissionManagementSystem::dropSpacecraftFromMission(const string spacecraftName) {
    int spacecraftIndex = findSpacecraftIndex(spacecraftName);
    if (spacecraftIndex == -1) {
        cout << "Spacecraft does not exist." << endl;
        return;
    }
    if (spacecrafts[spacecraftIndex].getStatus() == "Available") {
        cout << "Spacecraft is not assigned to any mission." << endl;
        return;
    }

    string missionName = spacecrafts[spacecraftIndex].getAssignedMission();
    int missionIndex = findMissionIndex(missionName);
    spacecrafts[spacecraftIndex].unassign();
    if (missionIndex != -1) {
        missions[missionIndex].removeSpacecraft(spacecraftName);
    }
}

void SpaceMissionManagementSystem::showAllMissions() const {
    for (int i = 0; i < missionCount; ++i) {
        missions[i].displayMissionInfo();
    }
}

void SpaceMissionManagementSystem::showAllSpacecrafts() const {
    for (int i = 0; i < spacecraftCount; ++i) {
        spacecrafts[i].displaySpacecraftInfo();
    }
}

void SpaceMissionManagementSystem::showMission(const string name) const {
    int index = findMissionIndex(name);
    if (index == -1) {
        cout << "Mission does not exist." << endl;
        return;
    }
    missions[index].displayMissionInfo();
}

void SpaceMissionManagementSystem::showSpacecraft(const string name) const {
    int index = findSpacecraftIndex(name);
    if (index == -1) {
        cout << "Spacecraft does not exist." << endl;
        return;
    }
    spacecrafts[index].displaySpacecraftInfo();
}

int SpaceMissionManagementSystem::findMissionIndex(const string name) const {
    for (int i = 0; i < missionCount; ++i) {
        if (missions[i].getName() == name) {
            return i;
        }
    }
    return -1;
}

int SpaceMissionManagementSystem::findSpacecraftIndex(const string name) const {
    for (int i = 0; i < spacecraftCount; ++i) {
        if (spacecrafts[i].getName() == name) {
            return i;
        }
    }
    return -1;
}
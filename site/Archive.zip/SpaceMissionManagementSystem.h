#include <iostream>
#ifndef SPACEMISSIONMANAGEMENTSYSTEM_H
#define SPACEMISSIONMANAGEMENTSYSTEM_H


using namespace std;

class SpaceMissionManagementSystem {
private:
    class Mission {
    public:
        string name;
        string launchDate;
        string destination;
        string* assignedSpacecrafts; // Dynamically allocated array of spacecraft names
        int assignedCount;
        int assignedCapacity;

        Mission(const string& name, const string& launchDate, const string& destination);
        ~Mission();
        void addSpacecraft(const string& spacecraftName);
        void removeSpacecraft(const string& spacecraftName);
        void show() const;
    };

    class Spacecraft {
    public:
        string name;
        string type;
        string status;

        Spacecraft(const string& name, const string& type);
    };

    Mission** missions; // Dynamically allocated array of Mission pointers
    Spacecraft** spacecrafts; // Dynamically allocated array of Spacecraft pointers
    int missionCount;
    int spacecraftCount;
    int missionCapacity;
    int spacecraftCapacity;

    void resizeMissions();
    void resizeSpacecrafts();

public:
    SpaceMissionManagementSystem();
    ~SpaceMissionManagementSystem();
    
    void addMission(const string name, const string launchDate, const string destination);
    void removeMission(const string name);
    void addSpacecraft(const string name, const string type);
    void removeSpacecraft(const string name);
    void assignSpacecraftToMission(const string spacecraftName, const string missionName);
    void dropSpacecraftFromMission(const string spacecraftName);
    void showAllMissions() const;
    void showAllSpacecrafts() const;
    void showMission(const string name) const;
    void showSpacecraft(const string name) const;
};

#endif // SPACEMISSIONMANAGEMENTSYSTEM_H
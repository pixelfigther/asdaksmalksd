#include "Spacecraft.h"

Spacecraft::Spacecraft(const string& name, const string& type)
    : name(name), type(type), status("Available"), assignedMission("") {}

string Spacecraft::getAssignedMission() const {
    return assignedMission; 
}

void Spacecraft::assignToMission(const string& missionName) {
    assignedMission = missionName; 
    status = "Assigned"; 
}

void Spacecraft::unassign() {
    assignedMission = ""; 
    status = "Available"; 
}

void Spacecraft::displaySpacecraftInfo() const {
    cout << "Spacecraft Name: " << name << ", Type: " << type 
         << ", Status: " << status;
    if (!assignedMission.empty()) {
        cout << ", Assigned Mission: " << assignedMission;
    }
    cout << endl;
}

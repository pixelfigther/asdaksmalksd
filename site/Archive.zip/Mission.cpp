#include "Mission.h"

// Mission constructor
Mission::Mission(const string& name, const string& launchDate, const string& destination)
    : name(name), launchDate(launchDate), destination(destination), assignedCount(0), assignedCapacity(2) {
    assignedSpacecrafts = new string[assignedCapacity];
}

// Mission destructor
Mission::~Mission() {
    delete[] assignedSpacecrafts;
}

// Add spacecraft to the mission
void Mission::addSpacecraft(const string& spacecraftName) {
    if (assignedCount >= assignedCapacity) {
        assignedCapacity *= 2;
        string* newSpacecrafts = new string[assignedCapacity];
        for (int i = 0; i < assignedCount; i++) {
            newSpacecrafts[i] = assignedSpacecrafts[i];
        }
        delete[] assignedSpacecrafts;
        assignedSpacecrafts = newSpacecrafts;
    }
    assignedSpacecrafts[assignedCount++] = spacecraftName;
}

// Remove spacecraft from the mission
void Mission::removeSpacecraft(const string& spacecraftName) {
    for (int i = 0; i < assignedCount; i++) {
        if (assignedSpacecrafts[i] == spacecraftName) {
            assignedSpacecrafts[i] = assignedSpacecrafts[--assignedCount]; // Replace with last element
            return;
        }
    }
}

// Show mission details
void Mission::show() const {
    cout << "Mission: " << name << ", Launch Date: " << launchDate << ", Destination: " << destination
         << ", Assigned Spacecraft Count: " << assignedCount << endl;
    if (assignedCount > 0) {
        cout << "Assigned Spacecrafts:" << endl;
        for (int i = 0; i < assignedCount; i++) {
            cout << "- " << assignedSpacecrafts[i] << endl;
        }
    } else {
        cout << "Assigned Spacecrafts: None" << endl;
    }
}

#include <string>
#ifndef SPACECRAFT_H
#define SPACECRAFT_H


using namespace std;

class Spacecraft {
public:
    string name;
    string type;
    string status;
    string assignedMission;   

    Spacecraft(const string& name, const string& type);

    string getAssignedMission() const;
    void assignToMission(const string& missionName);
    void unassign();
    void displaySpacecraftInfo() const;     
};

#endif 